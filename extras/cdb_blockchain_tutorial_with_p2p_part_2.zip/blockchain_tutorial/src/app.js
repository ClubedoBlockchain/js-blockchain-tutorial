const express = require('express')
const bodyParser = require("body-parser");
const Blockchain = require('./blockchain');
const { v4: uuidv4 } = require('uuid');
const axios = require("axios");

const getService = (url) => {
    return axios.create({ baseURL: url })
}

const runServer = (port) => {

    const blockchain = new Blockchain(port);

    const address = uuidv4().split('-').join("");

    const app = express()
    app.use(bodyParser.json());
    app.use(bodyParser.urlencoded({ extended: false }));

    app.get('/blockchain', (req, res) => {
        res.json(blockchain)
    })
    
    app.post("/register-and-broadcast-node", async (req, res) => {
        const { newNodeUrl } = req.body;

        blockchain.addNode(newNodeUrl);

        const regNodes = [];
        blockchain.networkNodes.forEach((networkUrl) => {
            if (newNodeUrl !== networkUrl) {
                try {

                    regNodes.push(getService(networkUrl).post("/register-node", { newNodeUrl }))
                } catch (error) {
                    console.error('Error: ', error.message);
                }
            }
        })

        Promise.all(regNodes).then(data => {

            getService(newNodeUrl).post("/register-nodes-bulk",
                { allNetworkNodes: blockchain.getAllNodes() })
        }).catch(e => console.error)

        res.json({ message: `Found and register`, nodes: blockchain.getAllNodes() })
    })

    app.post("/register-node", (req, res) => {
        const { newNodeUrl } = req.body;

        blockchain.addNode(newNodeUrl);

        res.json({ message: `Registered nodes`, nodes: blockchain.getAllNodes() })
    })

    app.post("/register-nodes-bulk", (req, res) => {
        const { allNetworkNodes } = req.body;

        blockchain.networkNodes = allNetworkNodes.filter(node => node !== blockchain.currentNodeUrl);

        res.json({ message: `Registered nodes`, nodes: blockchain.getAllNodes() })
    })

    app.listen(port, () => {
        console.log(`Listening on port ${port}`)
    })

}

module.exports = runServer